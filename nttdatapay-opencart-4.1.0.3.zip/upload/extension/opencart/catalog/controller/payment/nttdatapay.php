<?php
namespace Opencart\Catalog\Controller\Extension\Opencart\Payment;

require __DIR__ . "/lib/AtomAES.php";
class Nttdatapay extends \Opencart\System\Engine\Controller
{
    private const NTTDATAPAY_UAT_API_ENDPOINT = 'https://paynetzuat.atomtech.in/ots/aipay/auth';
    private const NTTDATAPAY_PRODUCTION_API_ENDPOINT = 'https://payment1.atomtech.in/ots/aipay/auth';

    private const NTTDATAPAY_UAT_JS_CDN_LINK = 'https://pgtest.atomtech.in/staticdata/ots/js/atomcheckout.js';
    private const NTTDATAPAY_PRODUCTION_JS_CDN_LINK = 'https://psa.atomtech.in/staticdata/ots/js/atomcheckout.js';
    
    private const NTTDATAPAY_UAT_ENVIRONMENT = 'uat';
    private const NTTDATAPAY_PRODUCTION_ENVIRONMENT = 'production';
    private const NTTDATAPAY_API_VERSION = '2025-10-27';

    private string $app_id;
    private string $secret_key;
    private string $api_endpoint;
    private string $environment;
    private string $js_cdn_link;
    private string $encryption_key;
    private string $decryption_key;
    private string $request_hash_key;
    private string $response_hash_key;
    private string $productid;

    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->app_id = trim($this->config->get('payment_nttdatapay_app_id') ?? '');
        $this->secret_key = trim($this->config->get('payment_nttdatapay_secret_key') ?? '');
        $this->encryption_key = trim($this->config->get('payment_nttdatapay_encryption_key') ?? '');
        $this->decryption_key = trim($this->config->get('payment_nttdatapay_decryption_key') ?? '');
        $this->request_hash_key = trim($this->config->get('payment_nttdatapay_requesthash_key') ?? '');
        $this->response_hash_key = trim($this->config->get('payment_nttdatapay_responsehash_key') ?? '');
        $this->productid = trim($this->config->get('payment_nttdatapay_productid_key') ?? '');
        
        if ($this->config->get('payment_nttdatapay_sandbox')) {
            $this->api_endpoint = self::NTTDATAPAY_UAT_API_ENDPOINT;
            $this->environment = self::NTTDATAPAY_UAT_ENVIRONMENT;
            $this->js_cdn_link = self::NTTDATAPAY_UAT_JS_CDN_LINK;
        } else {
            $this->api_endpoint = self::NTTDATAPAY_PRODUCTION_API_ENDPOINT;
            $this->environment = self::NTTDATAPAY_PRODUCTION_ENVIRONMENT;
            $this->js_cdn_link = self::NTTDATAPAY_PRODUCTION_JS_CDN_LINK;
        }

    }

    private function log($message) {
      if ($this->config->get('payment_nttdatapay_enablelog')) {
        $log = new \Opencart\System\Library\Log('ndpspg.log');
        $log->write('[' . date('Y-m-d H:i:s') . '] ' . $message);
      }
    }

    public function index()
    {
        $this->load->language('extension/opencart/payment/nttdatapay');
        
        $this->log('NTTDATAPAY environment: '. $this->environment);

        $this->load->model('checkout/order');
        $order_id   = (int)($this->session->data['order_id'] ?? 0);
        if (!$order_id) {
            $this->log('[NTTDATAPAY] Missing order_id in session');
            return $this->response->redirect($this->url->link('checkout/cart'));
        }

        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (!$order_info) {
            $this->log('[NTTDATAPAY] Order not found: ' . $order_id);
            return $this->response->redirect($this->url->link('checkout/cart'));
        }
       
        $data['useremail'] = substr($order_info['email'], 0, 75);
        $data['usermobile'] = substr(html_entity_decode($order_info['telephone'], ENT_QUOTES, 'UTF-8'), 0, 20);
        
        $formatted_amount = number_format(
          (float)$order_info['total'] * (float)$order_info['currency_value'],
          2,
          '.',
          '');

        $atomenc = new AtomAES();

        $curl = curl_init();
        $merchTxnId = (string)(time() . $order_id);

            $payload = [
        'payInstrument' => [
            'headDetails' => [
                'version'  => 'OTSv1.1',
                'api'      => 'AUTH',
                'platform' => 'FLASH'
            ],
            'merchDetails' => [
                'merchId'     => (string)$this->app_id,
                'userId'      => '',
                'password'    => (string)$this->secret_key,
                'merchTxnId'  => $merchTxnId,
                'merchTxnDate'=> date('Y-m-d H:i:s')
            ],
            'payDetails' => [
                'amount'      => $formatted_amount,
                'product'     => (string)$this->productid,
                'custAccNo'   => '213232323',
                'txnCurrency' => 'INR' // send INR since we converted
            ],
            'custDetails' => [
                'custEmail'  => $data['useremail'],
                'custMobile' => $data['usermobile']
            ],
            'extras' => [
                'udf1' => (string)$order_id,
                'udf2' => '',
                'udf3' => '',
                'udf4' => '',
                'udf5' => ''
            ]
        ]
    ];
    $jsondata = json_encode($payload, JSON_UNESCAPED_SLASHES);

        $encData = $atomenc->encrypt($jsondata, $this->encryption_key, $this->encryption_key);
        $this->log('NTTDATAPAY encrypted data: '. $encData);

         curl_setopt_array($curl, array(
              CURLOPT_URL => $this->api_endpoint,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_SSL_VERIFYHOST => 2,
              CURLOPT_SSL_VERIFYPEER => 1,
              CURLOPT_CAINFO => __DIR__ . "/lib/cacert.pem",
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "encData=".$encData."&merchId=".$this->app_id,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/x-www-form-urlencoded"
              ),
            ));

            $atomTokenId = null;
            $response = curl_exec($curl);
           
            $this->log('NTTDATAPAY AUTH API response: '. $response);
            $getresp = explode("&", $response);
            $encresp = substr($getresp[1], strpos($getresp[1], "=") + 1);
            $decData = $atomenc->decrypt($encresp, $this->decryption_key, $this->decryption_key);

            if(curl_errno($curl)) {
                $error_msg = curl_error($curl);
                echo "error = ".$error_msg;
            }      

            if(isset($error_msg)) {
                echo "error = ".$error_msg;
            }   

            curl_close($curl);

            $res = json_decode($decData, true);        
            if($res){
              if($res['responseDetails']['txnStatusCode'] == 'OTS0000'){
                $atomTokenId = $res['atomTokenId'];
                $method_data['atomTokenId'] = $atomTokenId;
                $method_data['returnUrl'] = $this->url->link('extension/opencart/payment/nttdatapay|confirm');
                $method_data['cdnLink'] = $this->js_cdn_link . '?v=' . time();
                $method_data['loginid'] = $this->app_id;
                $method_data['emailid'] = $data['useremail'];
                $method_data['mobileno'] = $data['usermobile'];
                $method_data['orderId'] = $this->session->data['order_id'];
              }else{
                echo "Error getting data";
                $atomTokenId = null;
              }
            }

        $view_data = [
            'button_confirm' => $this->language->get('button_confirm'),
            'text_loading'   => $this->language->get('text_loading'),
            'text_redirect'  => $this->language->get('text_redirect'),
        ];

        return $this->load->view(
            'extension/opencart/payment/nttdatapay',
            array_merge($view_data, $method_data)
        );

    }

  public function confirm(): void {
        // If you placed AtomAES under system/library/Ndpspg/AtomAES.php with namespace,
        // use the fully qualified class below, e.g. \Opencart\System\Library\Ndpspg\AtomAES
        try {
            // 1) Basic presence check
            $encdata = $this->request->post['encData'] ?? '';
            if ($encdata === '') {
                $this->log('[NTTDATAPAY confirm] Missing encData');
                $this->response->redirect($this->url->link('common/home'));
                return;
            }

            // 2) Decrypt payload
            // Ensure AtomAES is autoloadable. Adjust the class path/namespace as per where you keep it.
            $atomenc   = new AtomAES(); // or new \Opencart\System\Library\Ndpspg\AtomAES();
            $key       = (string)$this->decryption_key;   // keep your config key
            $decrypted = $atomenc->decrypt($encdata, $key, $key);
            $this->log('[NTTDATAPAY confirm] Decrypted: ' . $decrypted);

            $jsonData = json_decode($decrypted, true);
            if (!is_array($jsonData)) {
                $this->log('[NTTDATAPAY confirm] JSON decode failed');
                $this->response->redirect($this->url->link('common/home'));
                return;
            }

            // 3) Extract order id (your older code used udf1)
            $order_id = (int)($jsonData['payInstrument']['extras']['udf1'] ?? 0);
            if ($order_id <= 0) {
                $this->log('[NTTDATAPAY confirm] No order_id found in udf1');
                $this->response->redirect($this->url->link('common/home'));
                return;
            }

            $this->load->language('extension/opencart/payment/nttdatapay');
            $this->load->model('checkout/order');

            $order_info = $this->model_checkout_order->getOrder($order_id);
            if (!$order_info) {
                $this->log('[NTTDATAPAY confirm] Order not found: ' . $order_id);
                $this->response->redirect($this->url->link('common/home'));
                return;
            }

            // 4) Decide status (success code unchanged: OTS0000)
            $status_code = (string)($jsonData['payInstrument']['responseDetails']['statusCode'] ?? '');
            $merch_txn   = (string)($jsonData['payInstrument']['merchDetails']['merchTxnId'] ?? '');
            $is_success  = ($status_code === 'OTS0000');

            // 5) Status IDs from settings (fallbacks provided)
            $success_status_id = (int)$this->config->get('payment_nttdatapay_order_status_success_id') ?: 2;  // Processing
            $failed_status_id  = (int)$this->config->get('payment_nttdatapay_order_status_failed_id')  ?: 10; // Failed

            if ($is_success) {
                $comment = 'Payment successful. MerchTxnId: ' . $merch_txn;
                // OC4 uses addHistory (not addOrderHistory)
                $this->model_checkout_order->addHistory($order_id, $success_status_id, $comment, true);
                $this->response->redirect($this->url->link('checkout/success'));
            } else {
                $comment = 'Payment failed. MerchTxnId: ' . $merch_txn . ' | Code: ' . $status_code;
                $this->model_checkout_order->addHistory($order_id, $failed_status_id, $comment, false);

                // Store failure message for display on failure page
                $failure_message = '⚠️ Payment failed for your order. Please try again or contact support. '
                                . '(TxnId: ' . $merch_txn . ', Code: ' . $status_code . ')';

                // Save message to session (available in failure page)
                $this->session->data['error'] = $failure_message;
                $this->response->redirect($this->url->link('checkout/failure'));
            }
        } catch (\Throwable $e) {
            // Fail safe: try to mark order failed if we have it
            $this->log('[NTTDATAPAY confirm][ERROR] ' . $e->getMessage());

            try {
                if (!empty($order_id)) {
                    $this->load->model('checkout/order');
                    $failed_status_id = (int)$this->config->get('payment_nttdatapay_order_status_failed_id') ?: 10;
                    $this->model_checkout_order->addHistory(
                        (int)$order_id,
                        $failed_status_id,
                        'Exception in confirm: ' . $e->getMessage(),
                        false
                    );
                }
            } catch (\Throwable $ignored) {}

            $this->response->redirect($this->url->link('checkout/cart'));
        }
    }

}