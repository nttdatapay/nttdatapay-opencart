<?php
// Text
$_['text_title'] = 'Card/Net Banking/Wallet/UPI - Nttdatapay';
$_['text_description'] = 'Items on %s Order No: %s';
$_['nttdatapay_api_error'] = 'API call error : ';
$_['text_redirect'] = 'Redirecting...';
$_['nttdatapay_payment_success'] = 'Your transaction was successful.';
$_['nttdatapay_payment_failed'] = 'Your transaction has failed. Please try again.';
$_['nttdatapay_payment_pending'] = 'Your transaction is yet to be confirmed. Please wait for some time.';
$_['nttdatapay_payment_cancelled'] = 'Your transaction has been cancelled. Please try again.';
$_['nttdatapay_signature_mismatch'] = 'Failed to verify the response.';

?>