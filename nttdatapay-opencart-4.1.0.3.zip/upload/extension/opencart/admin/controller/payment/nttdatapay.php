<?php
namespace Opencart\Admin\Controller\Extension\Opencart\Payment;

class Nttdatapay extends \Opencart\System\Engine\Controller {
    private array $error = [];

    public function index(): void {
        $this->load->language('extension/opencart/payment/nttdatapay');
        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/opencart/payment/nttdatapay', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['save'] = $this->url->link('extension/opencart/payment/nttdatapay.save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        $data['payment_nttdatapay_app_id'] = $this->config->get('payment_nttdatapay_app_id');
        $data['payment_nttdatapay_secret_key'] = $this->config->get('payment_nttdatapay_secret_key');
        $data['payment_nttdatapay_encryption_key'] = $this->config->get('payment_nttdatapay_encryption_key');
        $data['payment_nttdatapay_decryption_key'] = $this->config->get('payment_nttdatapay_decryption_key');
        $data['payment_nttdatapay_requesthash_key'] = $this->config->get('payment_nttdatapay_requesthash_key');
        $data['payment_nttdatapay_responsehash_key'] = $this->config->get('payment_nttdatapay_responsehash_key');
        $data['payment_nttdatapay_productid_key'] = $this->config->get('payment_nttdatapay_productid_key');
        $data['payment_nttdatapay_sandbox'] = $this->config->get('payment_nttdatapay_sandbox');
        $data['payment_nttdatapay_enablelog'] = $this->config->get('payment_nttdatapay_enablelog');
        $data['payment_nttdatapay_order_status_id'] = $this->config->get('payment_nttdatapay_order_status_id');
        $data['payment_nttdatapay_geo_zone_id'] = $this->config->get('payment_nttdatapay_geo_zone_id');
        $data['payment_nttdatapay_status'] = $this->config->get('payment_nttdatapay_status');
        $data['payment_nttdatapay_sort_order'] = $this->config->get('payment_nttdatapay_sort_order');

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $this->load->model('localisation/geo_zone');
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/opencart/payment/nttdatapay', $data));
    }

    public function save(): void {
        $this->load->language('extension/opencart/payment/nttdatapay');
        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/opencart/payment/nttdatapay')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_nttdatapay', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}