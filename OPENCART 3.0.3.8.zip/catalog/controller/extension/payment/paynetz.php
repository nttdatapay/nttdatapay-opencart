<?php
require __DIR__ . "/lib/AtomAES.php";

class ControllerExtensionPaymentPaynetz extends Controller {

    private $logger;
    private $paynetz_login_id;
    private $paynetz_password;
    private $paynetz_res_enckey;
    private $paynetz_req_enckey;
    private $paynetz_req_IV;
    private $paynetz_res_IV;
    private $paynetz_cdn_link;
    private $paynetz_productid;
    private $paynetz_proxy_unamepass;
    private $paynetz_proxy_hostport;
    private $paynetz_isproxy;
    private $paynetz_url;

    public function __construct($arg)
    {
        $this->logger= new Log('paynetz.log');
        parent::__construct($arg);

    }

    public function start() { 

        $this->load->model('checkout/order');

        $apidata = [];

        $api_data['paynetz_login_id'] = $this->config->get('payment_paynetz_login_id');
        $api_data['paynetz_password'] = $this->config->get('payment_paynetz_password');
        $api_data['paynetz_res_enckey']  = $this->config->get('payment_paynetz_res_enckey');
        $api_data['paynetz_req_enckey'] = $this->config->get('payment_paynetz_req_enckey');
        $api_data['paynetz_req_IV']  = $this->config->get('payment_paynetz_req_IV');
        $api_data['paynetz_res_IV']  = $this->config->get('payment_paynetz_res_IV');
        $api_data['paynetz_cdn_link'] = $this->config->get('payment_paynetz_cdn_link');
        $api_data['paynetz_productid'] = $this->config->get('payment_paynetz_productid');
        $api_data['paynetz_proxy_unamepass']= $this->config->get('payment_paynetz_proxy_unamepass');
        $api_data['paynetz_proxy_hostport'] = $this->config->get('payment_paynetz_proxy_hostport');
        $api_data['paynetz_isproxy'] = $this->config->get('payment_paynetz_isproxy');
        $api_data['paynetz_testmode'] = $this->config->get('payment_paynetz_testmode');
        $api_data['paynetz_url']= $this->config->get('payment_paynetz_url');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $this->logger->write("Step 2: Creating new Order with ".$this->session->data['order_id']);

        if ($order_info['currency_code'] != "INR"){

            $this->load->model('localisation/currency');
            $currencies = $this->model_localisation_currency->getCurrencies();

            foreach ($currencies as $currency) { 
                if ($currency['code'] == $order_info['currency_code']) { 
                    $order_info['total'] == (float) ($order_info['total'] / $currency['value']) ; 
                    break;
                }
            }
        }    

        $order_info['roundAmount'] = round($order_info['total'],2);   

        $products = $this->cart->getProducts();
        $api_data['description'] = " ";

        foreach($products as $product => $values) { 
            $api_data['description'] = html_entity_decode($values['name']." - ".$values['quantity']."".$api_data['description'], ENT_QUOTES, 'UTF-8');
        }

        $session_orderid   =  $this->session->data['order_id'];

        $api_data['description'] = html_entity_decode($api_data['description']."("."Order ID: ".$session_orderid.")", ENT_QUOTES, 'UTF-8');

        if ($order_info) { 

            $api_data['name'] = substr(trim((html_entity_decode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'], ENT_QUOTES, 'UTF-8'))), 0, 20);
            $api_data['email'] 			= substr($order_info['email'], 0, 75);
            $api_data['phone'] 			= substr(html_entity_decode($order_info['telephone'], ENT_QUOTES, 'UTF-8'), 0, 20);
            $api_data['amount'] 		= $order_info['roundAmount'].'.00';
            $api_data['transaction_id'] = time()."-". $this->session->data['order_id'];
            
            $this->logger->write("Enc data Sending : ".print_r($encdata,true));

            $method_data['action'] = $api_data['paynetz_url'].'?'.$encdata;

        }else{
            $this->logger->write('No Order Info Found or Order Info is false');
            exit;
        }

        $method_data['telephone'] 	= substr(html_entity_decode($order_info['telephone'], ENT_QUOTES, 'UTF-8'), 0, 20);
        $method_data['footer'] 		= $this->load->controller('common/footer');
        $method_data['header'] 		= $this->load->controller('common/header');

        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/paynetz/paynetz_redirect')){
            $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/payment/paynetz/paynetz_redirect',$method_data));
        }else{
            $this->response->setOutput($this->load->view("extension/payment/paynetz/paynetz_redirect",$method_data));
        }

    }

    public function index(){ 
        if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) 
        {
            $method_data['action'] = $this->config->get('config_ssl') . 'index.php'; 
        }
        else{
            $method_data['action'] = $this->config->get('config_url') . 'index.php'; 
        }

        $this->logger->write("Action URL: " . $method_data['action']);
        $method_data['confirm'] = 'extension/payment/paynetz/start';
        $this->logger->write("Step 1: Redirecting to extension/payment/paynetz/start");
        
        $data['paynetz_login_id'] = $this->config->get('payment_paynetz_login_id');
        $data['paynetz_password'] = $this->config->get('payment_paynetz_password');
        $data['paynetz_res_enckey']  = $this->config->get('payment_paynetz_res_enckey');
        $data['paynetz_req_enckey'] = $this->config->get('payment_paynetz_req_enckey');
        $data['paynetz_req_IV']  = $this->config->get('payment_paynetz_req_IV');
        $data['paynetz_res_IV']  = $this->config->get('payment_paynetz_res_IV');
        $data['paynetz_cdn_link'] = $this->config->get('payment_paynetz_cdn_link');
        $data['paynetz_productid'] = $this->config->get('payment_paynetz_productid');
        $data['paynetz_proxy_unamepass']= $this->config->get('payment_paynetz_proxy_unamepass');
        $data['paynetz_proxy_hostport'] = $this->config->get('payment_paynetz_proxy_hostport');
        $data['paynetz_isproxy'] = $this->config->get('payment_paynetz_isproxy');
        $data['paynetz_testmode'] = $this->config->get('payment_paynetz_testmode');
        $data['paynetz_url']= $this->config->get('payment_paynetz_url');
        
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
       
        $data['useremail'] = substr($order_info['email'], 0, 75);
        $data['usermobile'] = substr(html_entity_decode($order_info['telephone'], ENT_QUOTES, 'UTF-8'), 0, 20);
        
         if ($order_info['currency_code'] != "INR"){
            $this->load->model('localisation/currency');
            $currencies = $this->model_localisation_currency->getCurrencies();
            foreach ($currencies as $currency) { 
                if ($currency['code'] == $order_info['currency_code']) { 
                    $order_info['total'] == (float) ($order_info['total'] / $currency['value']) ; 
                    break;
                }
            }
        }  

        $order_info['roundAmount'] = round($order_info['total'],2);  
        $data['amount'] = $order_info['roundAmount'].'.00';
        //Atom insta pay start
            $atomenc = new AtomAES();

            $curl = curl_init();

                $jsondata = '{
                  "payInstrument": {
                    "headDetails": {
                      "version": "OTSv1.1",      
                      "api": "AUTH",  
                      "platform": "FLASH"	
                    },
                    "merchDetails": {
                      "merchId": "'.$data['paynetz_login_id'].'",
                      "userId": "",
                      "password": "'.$data['paynetz_password'].'",
                      "merchTxnId": "'.time()."-". $this->session->data['order_id'].'",      
                      "merchTxnDate": "'.date("Y-m-d h:m:s").'"
                    },
                    "payDetails": {
                      "amount":  "'.$data['amount'].'",
                      "product": "'.$data['paynetz_productid'].'",
                      "custAccNo": "213232323",
                      "txnCurrency": "INR"
                    },	
                    "custDetails": {
                      "custEmail": "'.$data['useremail'].'",
                      "custMobile": "'.$data['usermobile'].'"
                    },
                    "extras": {
                        "udf1": "'.$this->session->data['order_id'].'",
                        "udf2": "",
                        "udf3": "",
                        "udf4": "",
                        "udf5": ""
                    }
                  }  
                }';
        
            $encData = $atomenc->encrypt($jsondata, $data['paynetz_req_enckey'], $data['paynetz_req_IV']);

            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->config->get('payment_paynetz_url'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_SSL_VERIFYHOST => 2,
              CURLOPT_SSL_VERIFYPEER => 1,
              CURLOPT_CAINFO => __DIR__ . "/lib/cacert.pem",
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "encData=".$encData."&merchId=".$data['paynetz_login_id'],
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/x-www-form-urlencoded"
              ),
            ));

            $atomTokenId = null;
            $response = curl_exec($curl);

            $getresp = explode("&", $response); 
            
            $encresp = substr($getresp[1], strpos($getresp[1], "=") + 1);       

            $decData = $atomenc->decrypt($encresp, $data['paynetz_res_enckey'], $data['paynetz_res_IV']);

            if(curl_errno($curl)) {
                $error_msg = curl_error($curl);
                echo "error = ".$error_msg;
            }      

            if(isset($error_msg)) {
                echo "error = ".$error_msg;
            }   

            curl_close($curl);

            $res = json_decode($decData, true);   
        
            if($res){
              if($res['responseDetails']['txnStatusCode'] == 'OTS0000'){
                $atomTokenId = $res['atomTokenId'];
                $method_data['atomTokenId'] = $atomTokenId;
                $method_data['returnUrl'] = $this->url->link('extension/payment/paynetz/confirm');
                $method_data['cdnLink'] = $this->config->get('payment_paynetz_cdn_link');
                $method_data['loginid'] = $data['paynetz_login_id'];
                $method_data['emailid'] = $data['useremail'];
                $method_data['mobileno'] = $data['usermobile'];
              }else{
                echo "Error getting data";
                 $atomTokenId = null;
              }
            }
//        Atom insta pay end
        
        return $this->load->view('extension/payment/paynetz/paynetz', $method_data);
    }

    public function confirm(){  
        
        if(isset($this->request->post['encData'])){
            $encdata = $this->request->post['encData'];
            $responseEncryptionKey = $this->config->get('payment_paynetz_res_enckey');
            $salt = $this->config->get('payment_paynetz_res_IV');
            $atomenc = new AtomAES();
            $decrypted = $atomenc->decrypt($encdata, $responseEncryptionKey, $salt);
            $jsonData = json_decode($decrypted, true);
            $this->logger->write("Decrypted data :".sprintf($decrypted));
 
//            echo "<pre>";
//            print_r($jsonData['payInstrument']['extras']['udf1']);
//            exit;
//            
            if(isset($encdata) && !empty($encdata))
            {  
                $order_id = $jsonData['payInstrument']['extras']['udf1'];  // order ID
                $this->logger->write("Extracted order id from udf1: ".$order_id);
                $this->load->model('checkout/order');
                $order_info = $this->model_checkout_order->getOrder($order_id);
                $this->logger->write("OREDR INFO ".json_encode($order_info));
             
                if($jsonData['payInstrument']['responseDetails']['statusCode'] =='OTS0000') {
                    $this->logger->write("Payment for ".$jsonData['payInstrument']['merchDetails']['merchTxnId']." was credited.");
                    $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_paynetz_order_status_id'), "Payment was successful", true);
                    $this->response->redirect($this->url->link('checkout/success', '', 'SSL'));
                 }else{
                    $this->logger->write("Payment for ".$jsonData['payInstrument']['merchDetails']['merchTxnId']." failed.");
                    $this->model_checkout_order->addOrderHistory($order_id, 10, "Payment failed for Order ID: ".$jsonData['payInstrument']['merchDetails']['merchTxnId']."", true);
                    $this->session->data['error'] = 'Failed : Payment for the order has been failed ';
                    $this->response->redirect($this->url->link('checkout/cart', '', 'SSL'));
                }
             }else{
                $this->logger->write("No order Id Found");
                $this->response->redirect($this->config->get('config_url'));
            }
        }else{
            $this->logger->write("Callback called with no Encrypted data or Failed.");
            $this->response->redirect($this->config->get('config_url'));
        }
     

    }


}
