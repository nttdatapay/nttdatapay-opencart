<?php

$_['text_title'] = 'Pay using CC/DB/NB';
